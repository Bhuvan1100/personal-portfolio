import React from 'react';
import { motion } from 'framer-motion';
import { 
  FileText, 
  Download, 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  Code, 
  Trophy, 
  Hash, 
  Code2, 
  Cpu, 
  Folder, 
  ExternalLink, 
  Github 
} from 'lucide-react';

const Resume: React.FC = () => {
  const downloadCV = () => {
    // In a real application, this would download the actual CV file
    const link = document.createElement('a');
    link.href = '/BhuvanCV.pdf'; // This would be served by the backend
    link.download = 'Bhuvan_Bhaskar_Deo_CV.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const profiles = [
    { name: 'Codeforces', icon: Trophy, color: 'orange', url: '#' },
    { name: 'HackerRank', icon: Hash, color: 'green', url: '#' },
    { name: 'LeetCode', icon: Code2, color: 'yellow', url: '#' },
    { name: 'GeeksforGeeks', icon: Cpu, color: 'blue', url: '#' },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="py-20 bg-slate-800/50 dark:bg-slate-800/50 min-h-screen" id="resume">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white dark:text-white mb-4 flex items-center justify-center">
              <FileText className="w-8 h-8 mr-3 text-blue-400 dark:text-blue-400" />
              Resume
            </h2>
            <p className="text-lg text-slate-400 dark:text-slate-400 max-w-2xl mx-auto mb-8">
              Complete overview of my education, experience, and technical skills.
            </p>
            {/* Download Button */}
            <motion.button 
              onClick={downloadCV}
              className="px-8 py-4 bg-blue-600 dark:bg-blue-600 hover:bg-blue-700 dark:hover:bg-blue-700 text-white dark:text-white font-semibold rounded-lg transition-all duration-200 shadow-lg hover:shadow-blue-500/25 dark:hover:shadow-blue-500/25 flex items-center space-x-2 mx-auto"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Download className="w-5 h-5" />
              <span>Download CV</span>
            </motion.button>
          </motion.div>
          
          {/* Resume Content Grid */}
          <motion.div 
            className="grid lg:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {/* Left Column - Personal Info & Contact */}
            <div className="lg:col-span-1 space-y-6">
              {/* Personal Information */}
              <motion.div 
                className="bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50"
                variants={itemVariants}
              >
                <h3 className="text-xl font-semibold text-white dark:text-white mb-4 flex items-center">
                  <User className="w-5 h-5 mr-2 text-blue-400 dark:text-blue-400" />
                  Personal Info
                </h3>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 text-slate-400 dark:text-slate-400 mr-3" />
                    <span className="text-slate-300 dark:text-slate-300">9308302661</span>
                  </div>
                  <div className="flex items-center">
                    <Mail className="w-4 h-4 text-slate-400 dark:text-slate-400 mr-3" />
                    <span className="text-slate-300 dark:text-slate-300">bhaskarbhuvan2004@gmail.com</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 text-slate-400 dark:text-slate-400 mr-3" />
                    <span className="text-slate-300 dark:text-slate-300">Jharkhand, India</span>
                  </div>
                </div>
              </motion.div>
              
              {/* Coding Profiles */}
              <motion.div 
                className="bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50"
                variants={itemVariants}
              >
                <h3 className="text-xl font-semibold text-white dark:text-white mb-4 flex items-center">
                  <Code className="w-5 h-5 mr-2 text-blue-400 dark:text-blue-400" />
                  Coding Profiles
                </h3>
                <div className="space-y-3">
                  {profiles.map((profile) => {
                    const Icon = profile.icon;
                    const colorClasses = {
                      orange: 'text-orange-400 dark:text-orange-400',
                      green: 'text-green-400 dark:text-green-400',
                      yellow: 'text-yellow-400 dark:text-yellow-400',
                      blue: 'text-blue-400 dark:text-blue-400',
                    };

                    return (
                      <a 
                        key={profile.name}
                        href={profile.url} 
                        className="flex items-center justify-between p-3 bg-slate-800/50 dark:bg-slate-800/50 rounded-lg hover:bg-slate-700/50 dark:hover:bg-slate-700/50 transition-colors duration-200 group"
                      >
                        <div className="flex items-center">
                          <Icon className={`w-4 h-4 ${colorClasses[profile.color as keyof typeof colorClasses]} mr-3`} />
                          <span className="text-slate-300 dark:text-slate-300 group-hover:text-white dark:group-hover:text-white">{profile.name}</span>
                        </div>
                        <ExternalLink className="w-4 h-4 text-slate-500 dark:text-slate-500 group-hover:text-blue-400 dark:group-hover:text-blue-400" />
                      </a>
                    );
                  })}
                </div>
              </motion.div>
            </div>
            
            {/* Right Column - Projects & Technical Skills */}
            <div className="lg:col-span-2 space-y-6">
              {/* Featured Projects */}
              <motion.div 
                className="bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50"
                variants={itemVariants}
              >
                <h3 className="text-xl font-semibold text-white dark:text-white mb-6 flex items-center">
                  <Folder className="w-5 h-5 mr-2 text-blue-400 dark:text-blue-400" />
                  Featured Projects
                </h3>
                <div className="space-y-6">
                  {/* Project 1: Retail Store POS */}
                  <div className="border-l-4 border-blue-500 dark:border-blue-500 pl-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                      <h4 className="text-lg font-medium text-white dark:text-white">Retail Store POS Application</h4>
                      <span className="text-sm text-slate-400 dark:text-slate-400">April 2024 - Present</span>
                    </div>
                    <p className="text-slate-300 dark:text-slate-300 mb-3">Full-stack JavaScript app with CRUD operations, user authentication, and billing system.</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      <span className="px-2 py-1 bg-blue-600/20 text-blue-300 dark:text-blue-300 text-xs rounded-md">ReactJS</span>
                      <span className="px-2 py-1 bg-green-600/20 text-green-300 dark:text-green-300 text-xs rounded-md">Node.js</span>
                      <span className="px-2 py-1 bg-yellow-600/20 text-yellow-300 dark:text-yellow-300 text-xs rounded-md">Express.js</span>
                      <span className="px-2 py-1 bg-purple-600/20 text-purple-300 dark:text-purple-300 text-xs rounded-md">MongoDB</span>
                    </div>
                    <div className="flex space-x-4 text-sm">
                      <a href="#" className="text-blue-400 dark:text-blue-400 hover:text-blue-300 dark:hover:text-blue-300 flex items-center">
                        <ExternalLink className="w-3 h-3 mr-1" />
                        View Project
                      </a>
                      <a href="#" className="text-slate-400 dark:text-slate-400 hover:text-slate-300 dark:hover:text-slate-300 flex items-center">
                        <Github className="w-3 h-3 mr-1" />
                        Source Code
                      </a>
                    </div>
                  </div>
                  
                  {/* Project 2: Movie Recommender */}
                  <div className="border-l-4 border-purple-500 dark:border-purple-500 pl-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                      <h4 className="text-lg font-medium text-white dark:text-white">Movie Recommender System</h4>
                      <span className="text-sm text-slate-400 dark:text-slate-400">May 2024</span>
                    </div>
                    <p className="text-slate-300 dark:text-slate-300 mb-3">Machine Learning model that recommends movies based on user's movie choices.</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      <span className="px-2 py-1 bg-yellow-600/20 text-yellow-300 dark:text-yellow-300 text-xs rounded-md">Python</span>
                      <span className="px-2 py-1 bg-green-600/20 text-green-300 dark:text-green-300 text-xs rounded-md">Flask</span>
                      <span className="px-2 py-1 bg-orange-600/20 text-orange-300 dark:text-orange-300 text-xs rounded-md">HTML/CSS</span>
                    </div>
                    <div className="flex space-x-4 text-sm">
                      <a href="#" className="text-blue-400 dark:text-blue-400 hover:text-blue-300 dark:hover:text-blue-300 flex items-center">
                        <ExternalLink className="w-3 h-3 mr-1" />
                        View Project
                      </a>
                      <a href="#" className="text-slate-400 dark:text-slate-400 hover:text-slate-300 dark:hover:text-slate-300 flex items-center">
                        <Github className="w-3 h-3 mr-1" />
                        Source Code
                      </a>
                    </div>
                  </div>
                </div>
              </motion.div>
              
              {/* Technical Skills Summary */}
              <motion.div 
                className="bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50"
                variants={itemVariants}
              >
                <h3 className="text-xl font-semibold text-white dark:text-white mb-6 flex items-center">
                  <Cpu className="w-5 h-5 mr-2 text-blue-400 dark:text-blue-400" />
                  Technical Skills
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-white dark:text-white font-medium mb-3">Languages</h4>
                    <div className="flex flex-wrap gap-2">
                      <span className="px-3 py-1 bg-blue-600/20 text-blue-300 dark:text-blue-300 text-sm rounded-full">C++</span>
                      <span className="px-3 py-1 bg-yellow-600/20 text-yellow-300 dark:text-yellow-300 text-sm rounded-full">Python</span>
                      <span className="px-3 py-1 bg-orange-600/20 text-orange-300 dark:text-orange-300 text-sm rounded-full">JavaScript</span>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-white dark:text-white font-medium mb-3">Web Development</h4>
                    <div className="flex flex-wrap gap-2">
                      <span className="px-3 py-1 bg-blue-600/20 text-blue-300 dark:text-blue-300 text-sm rounded-full">ReactJS</span>
                      <span className="px-3 py-1 bg-green-600/20 text-green-300 dark:text-green-300 text-sm rounded-full">Node.js</span>
                      <span className="px-3 py-1 bg-red-600/20 text-red-300 dark:text-red-300 text-sm rounded-full">Express.js</span>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-white dark:text-white font-medium mb-3">CS Fundamentals</h4>
                    <div className="flex flex-wrap gap-2">
                      <span className="px-3 py-1 bg-purple-600/20 text-purple-300 dark:text-purple-300 text-sm rounded-full">DSA</span>
                      <span className="px-3 py-1 bg-indigo-600/20 text-indigo-300 dark:text-indigo-300 text-sm rounded-full">OOPS</span>
                      <span className="px-3 py-1 bg-pink-600/20 text-pink-300 dark:text-pink-300 text-sm rounded-full">OS</span>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-white dark:text-white font-medium mb-3">Tools & Database</h4>
                    <div className="flex flex-wrap gap-2">
                      <span className="px-3 py-1 bg-gray-600/20 text-gray-300 dark:text-gray-300 text-sm rounded-full">Git</span>
                      <span className="px-3 py-1 bg-slate-600/20 text-slate-300 dark:text-slate-300 text-sm rounded-full">GitHub</span>
                      <span className="px-3 py-1 bg-green-600/20 text-green-300 dark:text-green-300 text-sm rounded-full">MongoDB</span>
                      <span className="px-3 py-1 bg-blue-600/20 text-blue-300 dark:text-blue-300 text-sm rounded-full">SQL</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Resume;
