import React from 'react';
import { motion } from 'framer-motion';
import { Folder, Construction } from 'lucide-react';

const Projects: React.FC = () => {
  return (
    <div className="py-20 bg-slate-900 dark:bg-slate-900 min-h-screen" id="projects">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto text-center">
          {/* Section Header Only */}
          <motion.div 
            className="mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white dark:text-white mb-4 flex items-center justify-center">
              <Folder className="w-8 h-8 mr-3 text-blue-400 dark:text-blue-400" />
              Featured Projects
            </h2>
            <p className="text-lg text-slate-400 dark:text-slate-400 max-w-2xl mx-auto">
              Showcasing my development journey through innovative projects and solutions.
            </p>
          </motion.div>
          
          {/* Empty Content Area as requested */}
          <motion.div 
            className="min-h-[400px] flex items-center justify-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div className="text-center">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
              >
                <Construction className="w-16 h-16 text-slate-600 dark:text-slate-600 mx-auto mb-4" />
              </motion.div>
              <p className="text-slate-500 dark:text-slate-500 text-lg">Projects section under construction</p>
              <p className="text-slate-600 dark:text-slate-600 text-sm mt-2">Coming soon...</p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Projects;
