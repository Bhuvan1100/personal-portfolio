import React from 'react';
import { motion } from 'framer-motion';
import { 
  GraduationCap, 
  Cpu, 
  Trophy,
  Layout,
  Server,
  Code,
  Database,
  Zap,
  Terminal,
  Layers,
  GitBranch,
  Github,
  HardDrive,
  Code2,
  Medal,
  Target
} from 'lucide-react';

const About: React.FC = () => {
  const skills = [
    { name: 'React', icon: Layout, color: 'blue' },
    { name: 'Node.js', icon: Server, color: 'green' },
    { name: 'JavaScript', icon: Code, color: 'yellow' },
    { name: 'MongoDB', icon: Database, color: 'purple' },
    { name: 'Express.js', icon: Zap, color: 'red' },
    { name: 'C++', icon: Terminal, color: 'blue' },
    { name: 'Python', icon: Layers, color: 'yellow' },
    { name: 'Git', icon: GitBranch, color: 'orange' },
    { name: 'GitHub', icon: Github, color: 'gray' },
    { name: 'SQL', icon: HardDrive, color: 'indigo' },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  const skillCardVariants = {
    hidden: { scale: 0.8, opacity: 0 },
    visible: {
      scale: 1,
      opacity: 1,
      transition: { duration: 0.5 }
    },
    hover: {
      scale: 1.05,
      transition: { duration: 0.2 }
    }
  };

  return (
    <div className="py-20 bg-slate-800/50 dark:bg-slate-800/50 min-h-screen" id="about">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white dark:text-white mb-4">About Me</h2>
            <p className="text-lg text-slate-400 dark:text-slate-400 max-w-2xl mx-auto">
              Passionate developer with a strong foundation in computer science and hands-on experience 
              in full-stack development and competitive programming.
            </p>
          </motion.div>
          
          {/* Education Section */}
          <motion.div 
            className="mb-16"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h3 
              className="text-2xl font-semibold text-white dark:text-white mb-8 flex items-center"
              variants={itemVariants}
            >
              <GraduationCap className="w-6 h-6 mr-3 text-blue-400 dark:text-blue-400" />
              Education
            </motion.h3>
            <div className="space-y-6">
              <motion.div 
                className="bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50 hover:border-blue-500/50 dark:hover:border-blue-500/50 transition-all duration-200"
                variants={itemVariants}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-3">
                  <h4 className="text-xl font-semibold text-white dark:text-white">National Institute of Technology, Jamshedpur</h4>
                  <span className="text-slate-400 dark:text-slate-400">August 2023 – August 2027</span>
                </div>
                <p className="text-blue-400 dark:text-blue-400 font-medium mb-2">B.Tech in Electronics and Communications Engineering</p>
                <p className="text-slate-300 dark:text-slate-300">CGPA: 8.12</p>
                <p className="text-slate-400 dark:text-slate-400 text-sm mt-2">Jharkhand, India</p>
              </motion.div>
              
              <motion.div 
                className="bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50"
                variants={itemVariants}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-3">
                  <h4 className="text-lg font-semibold text-white dark:text-white">DAV Hehal School, Ranchi</h4>
                  <span className="text-slate-400 dark:text-slate-400">April 2020 – April 2022</span>
                </div>
                <p className="text-slate-300 dark:text-slate-300">Class-12th CBSE | Percentage: 90.6%</p>
              </motion.div>
              
              <motion.div 
                className="bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50"
                variants={itemVariants}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-3">
                  <h4 className="text-lg font-semibold text-white dark:text-white">St. Michael's School, Ranchi</h4>
                  <span className="text-slate-400 dark:text-slate-400">April 2010 – April 2020</span>
                </div>
                <p className="text-slate-300 dark:text-slate-300">Class-10th | Percentage: 95%</p>
              </motion.div>
            </div>
          </motion.div>
          
          {/* Professional Skills Grid */}
          <motion.div 
            className="mb-16"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h3 
              className="text-2xl font-semibold text-white dark:text-white mb-8 flex items-center"
              variants={itemVariants}
            >
              <Cpu className="w-6 h-6 mr-3 text-blue-400 dark:text-blue-400" />
              Professional Skillset
            </motion.h3>
            
            <motion.div 
              className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6"
              variants={containerVariants}
            >
              {skills.map((skill, index) => {
                const Icon = skill.icon;
                const colorClasses = {
                  blue: 'hover:border-blue-500/50 dark:hover:border-blue-500/50 text-blue-400 dark:text-blue-400 group-hover:text-blue-300 dark:group-hover:text-blue-300',
                  green: 'hover:border-green-500/50 dark:hover:border-green-500/50 text-green-400 dark:text-green-400 group-hover:text-green-300 dark:group-hover:text-green-300',
                  yellow: 'hover:border-yellow-500/50 dark:hover:border-yellow-500/50 text-yellow-400 dark:text-yellow-400 group-hover:text-yellow-300 dark:group-hover:text-yellow-300',
                  purple: 'hover:border-purple-500/50 dark:hover:border-purple-500/50 text-purple-400 dark:text-purple-400 group-hover:text-purple-300 dark:group-hover:text-purple-300',
                  red: 'hover:border-red-500/50 dark:hover:border-red-500/50 text-red-400 dark:text-red-400 group-hover:text-red-300 dark:group-hover:text-red-300',
                  orange: 'hover:border-orange-500/50 dark:hover:border-orange-500/50 text-orange-400 dark:text-orange-400 group-hover:text-orange-300 dark:group-hover:text-orange-300',
                  gray: 'hover:border-gray-500/50 dark:hover:border-gray-500/50 text-gray-400 dark:text-gray-400 group-hover:text-gray-300 dark:group-hover:text-gray-300',
                  indigo: 'hover:border-indigo-500/50 dark:hover:border-indigo-500/50 text-indigo-400 dark:text-indigo-400 group-hover:text-indigo-300 dark:group-hover:text-indigo-300',
                };

                return (
                  <motion.div
                    key={skill.name}
                    className={`bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50 ${colorClasses[skill.color as keyof typeof colorClasses]} transition-all duration-200 text-center group cursor-pointer`}
                    variants={skillCardVariants}
                    whileHover="hover"
                  >
                    <div className="w-12 h-12 mx-auto mb-3 transition-colors duration-200">
                      <Icon className="w-full h-full" />
                    </div>
                    <h4 className="text-white dark:text-white font-medium">{skill.name}</h4>
                  </motion.div>
                );
              })}
            </motion.div>
          </motion.div>
          
          {/* Achievements Section */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.h3 
              className="text-2xl font-semibold text-white dark:text-white mb-8 flex items-center"
              variants={itemVariants}
            >
              <Trophy className="w-6 h-6 mr-3 text-blue-400 dark:text-blue-400" />
              Achievements
            </motion.h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <motion.div 
                className="bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50 hover:border-yellow-500/50 dark:hover:border-yellow-500/50 transition-all duration-200"
                variants={itemVariants}
              >
                <div className="flex items-center mb-3">
                  <Code2 className="w-6 h-6 text-yellow-400 dark:text-yellow-400 mr-3" />
                  <h4 className="text-white dark:text-white font-medium">Competitive Programming</h4>
                </div>
                <p className="text-slate-300 dark:text-slate-300 text-sm">200+ problems solved on Codeforces (Max rating: 1163)</p>
              </motion.div>
              
              <motion.div 
                className="bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50 hover:border-green-500/50 dark:hover:border-green-500/50 transition-all duration-200"
                variants={itemVariants}
              >
                <div className="flex items-center mb-3">
                  <Medal className="w-6 h-6 text-green-400 dark:text-green-400 mr-3" />
                  <h4 className="text-white dark:text-white font-medium">Contest Ranking</h4>
                </div>
                <p className="text-slate-300 dark:text-slate-300 text-sm">Rank 5552 in Codeforces Round 759 Div-2 among 25000+ participants</p>
              </motion.div>
              
              <motion.div 
                className="bg-slate-900/50 dark:bg-slate-900/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 dark:border-slate-700/50 hover:border-blue-500/50 dark:hover:border-blue-500/50 transition-all duration-200"
                variants={itemVariants}
              >
                <div className="flex items-center mb-3">
                  <Target className="w-6 h-6 text-blue-400 dark:text-blue-400 mr-3" />
                  <h4 className="text-white dark:text-white font-medium">Problem Solving</h4>
                </div>
                <p className="text-slate-300 dark:text-slate-300 text-sm">1000+ questions solved across various CP platforms</p>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default About;
