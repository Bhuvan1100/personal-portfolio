import React from 'react';
import { motion } from 'framer-motion';
import { Code, Download, ChevronDown, Linkedin, Github, Mail } from 'lucide-react';
import TypewriterEffect from '@/components/TypewriterEffect';

const Home: React.FC = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const downloadResume = () => {
    // Create a link to download the CV
    const link = document.createElement('a');
    link.href = '/api/download-cv'; // This would be handled by the backend
    link.download = 'Bhuvan_Bhaskar_Deo_CV.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-slate-900 dark:bg-slate-900">
      {/* Background with coding workspace imagery */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
        <div className="absolute inset-0 bg-black/20 dark:bg-black/20"></div>
        <img 
          src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080" 
          alt="Professional developer workspace with multiple monitors" 
          className="w-full h-full object-cover opacity-10 dark:opacity-10" 
        />
      </div>
      
      <div className="container mx-auto px-4 z-10 text-center">
        <motion.div 
          className="max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          {/* Hero Text */}
          <div className="mb-8">
            <motion.h1 
              className="text-2xl md:text-3xl text-slate-400 dark:text-slate-400 mb-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              Hello, I'm
            </motion.h1>
            <div className="text-4xl md:text-6xl lg:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 mb-6">
              <TypewriterEffect text="Bhuvan Bhaskar Deo" speed={150} />
            </div>
            <motion.h2 
              className="text-xl md:text-2xl lg:text-3xl text-slate-300 dark:text-slate-300 font-medium mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1, duration: 0.5 }}
            >
              Full Stack Developer & Problem Solver
            </motion.h2>
          </div>
          
          {/* Hero Description */}
          <motion.p 
            className="text-lg md:text-xl text-slate-400 dark:text-slate-400 max-w-2xl mx-auto mb-12 leading-relaxed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 0.5 }}
          >
            B.Tech ECE student at NIT Jamshedpur, passionate about building scalable web applications 
            and solving complex algorithmic challenges. Experienced in MERN stack development.
          </motion.p>
          
          {/* CTA Buttons */}
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.4, duration: 0.5 }}
          >
            <motion.button 
              onClick={() => scrollToSection('projects')}
              className="px-8 py-4 bg-blue-600 dark:bg-blue-600 hover:bg-blue-700 dark:hover:bg-blue-700 text-white dark:text-white font-semibold rounded-lg transition-all duration-200 shadow-lg hover:shadow-blue-500/25 dark:hover:shadow-blue-500/25 flex items-center space-x-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Code className="w-5 h-5" />
              <span>View My Work</span>
            </motion.button>
            <motion.button 
              onClick={downloadResume}
              className="px-8 py-4 border border-slate-600 dark:border-slate-600 hover:border-blue-400 dark:hover:border-blue-400 text-slate-300 dark:text-slate-300 hover:text-blue-400 dark:hover:text-blue-400 font-semibold rounded-lg transition-all duration-200 flex items-center space-x-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Download className="w-5 h-5" />
              <span>Download Resume</span>
            </motion.button>
          </motion.div>
          
          {/* Social Links */}
          <motion.div 
            className="flex justify-center space-x-6 mt-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.6, duration: 0.5 }}
          >
            <motion.a 
              href="https://linkedin.com/in/Bhuvan-Bhaskar-Deo" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-3 bg-slate-800 dark:bg-slate-800 hover:bg-blue-600 dark:hover:bg-blue-600 rounded-full transition-all duration-200 group"
              whileHover={{ scale: 1.1 }}
            >
              <Linkedin className="w-6 h-6 text-slate-400 dark:text-slate-400 group-hover:text-white dark:group-hover:text-white" />
            </motion.a>
            <motion.a 
              href="https://github.com/Bhuvan1100" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-3 bg-slate-800 dark:bg-slate-800 hover:bg-slate-700 dark:hover:bg-slate-700 rounded-full transition-all duration-200 group"
              whileHover={{ scale: 1.1 }}
            >
              <Github className="w-6 h-6 text-slate-400 dark:text-slate-400 group-hover:text-white dark:group-hover:text-white" />
            </motion.a>
            <motion.a 
              href="mailto:bhaskarbhuvan2004@gmail.com"
              className="p-3 bg-slate-800 dark:bg-slate-800 hover:bg-green-600 dark:hover:bg-green-600 rounded-full transition-all duration-200 group"
              whileHover={{ scale: 1.1 }}
            >
              <Mail className="w-6 h-6 text-slate-400 dark:text-slate-400 group-hover:text-white dark:group-hover:text-white" />
            </motion.a>
          </motion.div>
        </motion.div>
      </div>
      
      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <ChevronDown className="w-6 h-6 text-slate-400 dark:text-slate-400" />
      </motion.div>
    </div>
  );
};

export default Home;
