import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/contexts/ThemeContext";
import Navigation from "@/components/Navigation";
import Home from "@/pages/Home";
import About from "@/pages/About";
import Projects from "@/pages/Projects";
import Resume from "@/pages/Resume";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="min-h-screen bg-slate-900 dark:bg-slate-900 text-white dark:text-white">
      <Navigation />
      <main className="pt-20">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/about" component={About} />
          <Route path="/projects" component={Projects} />
          <Route path="/resume" component={Resume} />
          <Route component={NotFound} />
        </Switch>
      </main>
      
      {/* Footer */}
      <footer className="bg-slate-900 dark:bg-slate-900 border-t border-slate-700/50 dark:border-slate-700/50 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8 mb-8">
              <div>
                <h3 className="text-white dark:text-white font-semibold mb-4">Get In Touch</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center">
                    <span className="text-slate-300 dark:text-slate-300">bhaskarbhuvan2004@gmail.com</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-slate-300 dark:text-slate-300">+91 9308302661</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-slate-300 dark:text-slate-300">Jharkhand, India</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-white dark:text-white font-semibold mb-4">Quick Links</h3>
                <div className="space-y-2 text-sm">
                  <div className="text-slate-300 dark:text-slate-300">Home</div>
                  <div className="text-slate-300 dark:text-slate-300">About</div>
                  <div className="text-slate-300 dark:text-slate-300">Projects</div>
                  <div className="text-slate-300 dark:text-slate-300">Resume</div>
                </div>
              </div>
              
              <div>
                <h3 className="text-white dark:text-white font-semibold mb-4">Connect With Me</h3>
                <div className="text-slate-300 dark:text-slate-300 text-sm">
                  LinkedIn • GitHub • Email
                </div>
              </div>
            </div>
            
            <div className="border-t border-slate-700/50 dark:border-slate-700/50 pt-8 text-center">
              <p className="text-slate-400 dark:text-slate-400 text-sm">
                © 2024 Bhuvan Bhaskar Deo. All rights reserved. Built with ❤️ using React & Tailwind CSS.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
